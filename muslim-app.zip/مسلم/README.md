# مسلم
1. ضع ملف الأذان باسم adhan.mp3 داخل فولدر www
2. ارفع كل الملفات على GitHub (فرع main)
3. افتح Actions > Build APK وانتظر
4. نزّل muslim-apk وثبّت app-debug.apk
