const $=s=>document.querySelector(s),$$=s=>[...document.querySelectorAll(s)];
const NATIVE=!!(window.Capacitor&&Capacitor.isNativePlatform&&Capacitor.isNativePlatform());
const PL=n=>Capacitor.Plugins[n];
const store={get(k,d){try{const v=localStorage.getItem(k);return v==null?d:JSON.parse(v)}catch(e){return d}},set(k,v){try{localStorage.setItem(k,JSON.stringify(v))}catch(e){}}};
const NAMES={Fajr:'الفجر',Dhuhr:'الظهر',Asr:'العصر',Maghrib:'المغرب',Isha:'العشاء'},KEYS=Object.keys(NAMES);
const ad=n=>String(n).replace(/\d/g,d=>'٠١٢٣٤٥٦٧٨٩'[d]);
const z=n=>String(n).padStart(2,'0');
const fmt=d=>((d.getHours()%12)||12)+':'+z(d.getMinutes())+' '+(d.getHours()<12?'ص':'م');
function toast(t){const e=$('#toast');e.textContent=t;e.classList.add('s');setTimeout(()=>e.classList.remove('s'),2200)}
const rad=x=>x*Math.PI/180;
function dist(a,b,c,d){const x=rad(c-a),y=rad(d-b),h=Math.sin(x/2)**2+Math.cos(rad(a))*Math.cos(rad(c))*Math.sin(y/2)**2;return 12742*Math.asin(Math.sqrt(h))}

/* tabs */
let TAB='times';
function go(t){TAB=t;$$('nav button').forEach(b=>b.classList.toggle('on',b.dataset.t===t));$$('.tab').forEach(e=>e.classList.toggle('on',e.id==='t-'+t));scrollTo(0,0);t==='qibla'?qiblaStart():qiblaStop()}
$$('nav button').forEach(b=>b.onclick=()=>go(b.dataset.t));

/* ---------- location ---------- */
let POS=store.get('pos',null);
async function geocode(){
  try{const j=await(await fetch(`https://api.bigdatacloud.net/data/reverse-geocode-client?latitude=${POS.lat}&longitude=${POS.lon}&localityLanguage=ar`)).json();
    POS.name=[j.city||j.locality,j.countryName].filter(Boolean).join('، ')||'موقعك الحالي';POS.cc=j.countryCode}catch(e){POS.name=POS.name||'موقعك الحالي'}
}
async function locate(){
  try{
    let c;
    if(NATIVE){const g=PL('Geolocation');await g.requestPermissions();c=(await g.getCurrentPosition({timeout:15000,maximumAge:300000})).coords}
    else c=await new Promise((ok,no)=>navigator.geolocation.getCurrentPosition(p=>ok(p.coords),no,{timeout:15000,maximumAge:300000}));
    const moved=!POS||!POS.exact||dist(POS.lat,POS.lon,c.latitude,c.longitude)>3;
    POS=moved?{}:POS;POS.lat=c.latitude;POS.lon=c.longitude;POS.exact=true;
    if(moved||!POS.name)await geocode();
  }catch(e){
    if(!POS||!POS.exact){POS=POS||{lat:30.0444,lon:31.2357,name:'القاهرة (موقع افتراضي)',cc:'EG',exact:false};toast('تعذر تحديد موقعك. فعّل GPS وصلاحية الموقع')}
  }
  store.set('pos',POS);$('#chip').textContent=POS.name;$('#locName').innerHTML=`${POS.name}<small style="color:var(--mute);display:block">${POS.exact?'من GPS':'غير دقيق'}</small>`;
}
const METH={EG:5,SA:4,KW:9,QA:10,AE:8,BH:8,OM:8,TR:13,PK:1,IN:1,BD:1,US:2,CA:2};
const method=()=>{const m=store.get('method','auto');return m==='auto'?(METH[POS&&POS.cc]||3):+m};

/* ---------- times ---------- */
async function getTimes(d){
  const key=`t${d.toDateString()}${POS.lat.toFixed(1)}${POS.lon.toFixed(1)}m${method()}`;
  let t=store.get(key,null);if(t)return t;
  const tz=Intl.DateTimeFormat().resolvedOptions().timeZone;
  const r=await fetch(`https://api.aladhan.com/v1/timings/${Math.floor(d/1000)}?latitude=${POS.lat}&longitude=${POS.lon}&method=${method()}&timezonestring=${encodeURIComponent(tz)}`);
  t=(await r.json()).data.timings;store.set(key,t);return t;
}
const at=(hm,d)=>{const [h,m]=hm.split(' ')[0].split(':').map(Number),x=new Date(d);x.setHours(h,m,0,0);return x};
let TM=null;
function events(){const d=new Date(),e={};KEYS.forEach(k=>e[k]=at(TM[k],d));e.Sunrise=at(TM.Sunrise,d);return e}
function nextP(){const now=new Date(),e=events();for(const k of KEYS)if(e[k]>now)return{k,t:e[k]};const t=new Date(e.Fajr);t.setDate(t.getDate()+1);return{k:'Fajr',t}}
const SKY=[['#0a1230','#25357a'],['#2f3f8f','#e8908f'],['#2b7bbd','#8fd0ee'],['#1f6fb8','#6cbbe8'],['#d9822b','#f4c76a'],['#6a3470','#e0705a'],['#0a1230','#25357a']];
function render(){
  if(!TM)return;
  try{$('#hijri').textContent=new Intl.DateTimeFormat('ar-SA-u-ca-islamic-umalqura',{day:'numeric',month:'long',year:'numeric'}).format(new Date())+' هـ'}catch(e){}
  const e=events(),now=new Date(),n=nextP();
  $('#list').innerHTML=KEYS.slice(0,2).map(row).join('')+row('Sunrise')+KEYS.slice(2).map(row).join('');
  function row(k){const done=e[k]<=now,nx=k===n.k&&n.t>now&&!done,nm=k==='Sunrise'?'الشروق':NAMES[k];return `<div class="row ${k==='Sunrise'?'sm':''} ${done?'done':''} ${nx?'nx':''}"><i class="dot"></i><b>${nm}</b><span>${fmt(e[k])}</span></div>`}
  const seq=[e.Fajr,e.Sunrise,e.Dhuhr,e.Asr,e.Maghrib,e.Isha];let p=0;seq.forEach((t,i)=>{if(now>=t)p=i+1});
  const g=SKY[p];$('#sky').style.background=`linear-gradient(170deg,${g[0]},${g[1]})`;
  $('#nName').textContent=NAMES[n.k];$('#nAt').textContent=fmt(n.t);
  /* sun arc */
  const f=e.Fajr,span=e.Isha-f,B=t=>{const u=Math.min(1,Math.max(0,(t-f)/span)),w=1-u;return[w*w*300+2*w*u*160+u*u*20,w*w*120+2*w*u*-40+u*u*120]};
  let s='<path d="M300 120Q160 -40 20 120" fill="none" stroke="#fff" stroke-opacity=".45" stroke-width="2" stroke-dasharray="3 6"/><path d="M8 120H312" stroke="#fff" stroke-opacity=".3"/>';
  KEYS.forEach(k=>{const[x,y]=B(e[k]);s+=`<circle cx="${x}" cy="${y}" r="${k===n.k?5:3.5}" fill="#fff" fill-opacity="${e[k]<=now?.45:1}"/>`});
  const[sx,sy]=B(now),night=now<f||now>e.Isha;
  s+=night?`<circle cx="${now<f?300:20}" cy="120" r="9" fill="#e9eefc"/><circle cx="${now<f?296:16}" cy="117" r="8" fill="${g[0]}"/>`:`<circle cx="${sx}" cy="${sy}" r="20" fill="#ffd25e" fill-opacity=".3"/><circle cx="${sx}" cy="${sy}" r="9" fill="#ffd25e"/>`;
  $('#arc').innerHTML=s;
}
function tick(){if(!TM)return;const n=nextP(),s=Math.max(0,Math.floor((n.t-new Date())/1000));$('#nCd').textContent=`${z(Math.floor(s/3600))}:${z(Math.floor(s%3600/60))}:${z(s%60)}`;if(s===0)setTimeout(render,1500)}
setInterval(tick,1000);setInterval(render,30000);

/* ---------- notifications / adhan ---------- */
const SUN={Fajr:'ركعتان سنة الفجر قبل الفريضة',Dhuhr:'4 ركعات قبل الظهر وركعتان بعدها',Asr:'يُستحب 4 ركعات قبل العصر',Maghrib:'ركعتان بعد المغرب',Isha:'ركعتان بعد العشاء ثم الوتر'};
let adhan=new Audio('adhan.mp3'),timers=[];
function playAdhan(){adhan.currentTime=0;adhan.play().catch(()=>toast('اسمح بتشغيل الصوت أولًا'))}
async function nativeSchedule(){
  const LN=PL('LocalNotifications');
  try{
    const perm=await LN.requestPermissions();
    if(perm.display!=='granted'){$('#status').textContent='الإشعارات مقفولة. فعّلها من إعدادات أندرويد للتطبيق.';return}
    try{const ex=await LN.checkExactNotificationSetting();if(ex.exact_alarm!=='granted')await LN.changeExactNotificationSetting()}catch(e){}
    await LN.createChannel({id:'adhan',name:'الأذان',importance:5,sound:'adhan.mp3',vibration:true,visibility:1});
    await LN.createChannel({id:'reminder',name:'تذكير قبل الصلاة',importance:4,vibration:true,visibility:1});
    const pend=await LN.getPending();if(pend.notifications.length)await LN.cancel({notifications:pend.notifications});
    const list=[],now=new Date();let id=1;
    for(let i=0;i<7;i++){
      const d=new Date();d.setDate(d.getDate()+i);let tm;try{tm=await getTimes(d)}catch(e){continue}
      for(const k of KEYS){const t=at(tm[k],d),b=new Date(t-9e5);
        if(b>now)list.push({id:id++,title:'باقي ربع ساعة',body:'على صلاة '+NAMES[k],schedule:{at:b,allowWhileIdle:true},channelId:'reminder'});
        if(t>now)list.push({id:id++,title:'حان الآن موعد أذان '+NAMES[k],body:'حي على الصلاة • '+SUN[k],schedule:{at:t,allowWhileIdle:true},channelId:'adhan',sound:'adhan.mp3'})}
    }
    await LN.schedule({notifications:list});
    $('#status').textContent=`تم ضبط ${list.length} تنبيه للأسبوع القادم. افتح التطبيق مرة في الأسبوع لتجديدها.`;
  }catch(e){$('#status').textContent='خطأ في ضبط التنبيهات: '+e.message}
}
function webSchedule(){
  timers.forEach(clearTimeout);timers=[];const e=events(),now=new Date();
  const note=(t,b)=>{try{Notification.permission==='granted'&&new Notification(t,{body:b})}catch(x){}};
  KEYS.forEach(k=>{const t=e[k];
    if(t-9e5>now)timers.push(setTimeout(()=>note('باقي ربع ساعة','على صلاة '+NAMES[k]),t-9e5-now));
    if(t>now)timers.push(setTimeout(()=>{note('حان موعد أذان '+NAMES[k],SUN[k]);playAdhan()},t-now))});
}
$('#enable').onclick=async()=>{
  if(NATIVE)return nativeSchedule();
  try{await Notification.requestPermission()}catch(e){}
  adhan.muted=true;try{await adhan.play();adhan.pause()}catch(e){}adhan.muted=false;
  $('#status').textContent='تم التفعيل. اترك الصفحة مفتوحة، وللأذان وهي مقفولة استخدم نسخة التطبيق.';
};
$('#test').onclick=playAdhan;
$('#relocate').onclick=()=>start();
$('#method').value=store.get('method','auto');
$('#method').onchange=e=>{store.set('method',e.target.value);start(true)};

/* ---------- qibla ---------- */
const KAABA=[21.4225,39.8262];let HEAD=0,SENS=false,QB=0,wasOk=false,sensT;
function qDraw(){
  const ok=Math.abs(((QB-HEAD+540)%360)-180)<4;
  $('#dial').classList.toggle('ok',ok);
  if(ok&&!wasOk&&navigator.vibrate)navigator.vibrate(60);wasOk=ok;
  $('#dialRot').setAttribute('transform',`rotate(${-HEAD} 150 160)`);
  $('#qDeg').textContent=ok?'اتجاه القبلة ✓':Math.round(QB)+'°';
}
let GOTABS=false,OFF=store.get('off',0);
function tiltHeading(a,b,g){
  const r=Math.PI/180,x=b*r,y=g*r,w=a*r,cY=Math.cos(y),cZ=Math.cos(w),sX=Math.sin(x),sY=Math.sin(y),sZ=Math.sin(w);
  const Vx=-cZ*sY-sZ*sX*cY,Vy=-sZ*sY+cZ*sX*cY;let h=Math.atan(Vx/Vy);
  if(Vy<0)h+=Math.PI;else if(Vx<0)h+=2*Math.PI;return h/r;
}
function onOri(e){
  let h=e.webkitCompassHeading;
  if(h==null){if(e.alpha==null)return;h=tiltHeading(e.alpha,e.beta||0,e.gamma||0)}
  h=(h+OFF+(POS&&POS.dec||0)+360)%360;SENS=true;const d=((h-HEAD+540)%360)-180;HEAD=(HEAD+d*.25+360)%360;qDraw();
}
const oriA=e=>{GOTABS=true;onOri(e)},oriB=e=>{if(!GOTABS&&(e.webkitCompassHeading!=null||e.absolute))onOri(e)};
async function declination(){
  if(!POS||POS.dec!=null)return;
  try{const r=await fetch(`https://www.ngdc.noaa.gov/geomag-web/calculators/calculateDeclination?lat1=${POS.lat}&lon1=${POS.lon}&key=zNEw7&resultFormat=json`);
    const d=(await r.json()).result[0].declination;if(typeof d==='number'){POS.dec=d;store.set('pos',POS)}}catch(e){}
}
$('#oPlus').onclick=()=>{OFF=Math.min(30,OFF+1);store.set('off',OFF);$('#oVal').textContent=OFF+'°'};
$('#oMinus').onclick=()=>{OFF=Math.max(-30,OFF-1);store.set('off',OFF);$('#oVal').textContent=OFF+'°'};
async function qiblaStart(){
  if(!POS)return;
  $('#oVal').textContent=OFF+'°';
  await declination();
  const[a,b]=[rad(POS.lat),rad(POS.lon)],[c,d]=[rad(KAABA[0]),rad(KAABA[1])];
  QB=(Math.atan2(Math.sin(d-b)*Math.cos(c),Math.cos(a)*Math.sin(c)-Math.sin(a)*Math.cos(c)*Math.cos(d-b))*180/Math.PI+360)%360;
  let s='<g id="dialRot"><circle cx="150" cy="160" r="132" fill="#0b2b25" stroke="var(--acc)" stroke-width="2.5"/>';
  for(let i=0;i<72;i++){const m=i%6===0;s+=`<line x1="150" y1="${m?32:36}" x2="150" y2="${m?46:42}" stroke="var(--mute)" stroke-width="${m?2:1}" transform="rotate(${i*5} 150 160)"/>`}
  [['ش',0],['ق',90],['ج',180],['غ',270]].forEach(([t,r])=>s+=`<text x="150" y="68" text-anchor="middle" font-size="18" font-weight="700" fill="${r?'var(--mute)':'#dc2626'}" transform="rotate(${r} 150 160)">${t}</text>`);
  s+=`<g transform="rotate(${QB} 150 160)"><line x1="150" y1="160" x2="150" y2="86" stroke="var(--acc)" stroke-width="2" stroke-dasharray="4 4"/><rect x="136" y="72" width="28" height="28" rx="3" fill="#111"/><rect x="136" y="79" width="28" height="5" fill="#e0b04a"/></g></g>`;
  s+='<path class="tri" d="M150 4l-11 22h22z" fill="var(--acc)"/><circle cx="150" cy="160" r="5" fill="var(--acc)"/>';
  $('#dial').innerHTML=s;
  const km=dist(POS.lat,POS.lon,KAABA[0],KAABA[1]);
  $('#qInfo').textContent=`${POS.name} • تبعد عن الكعبة ${ad(Math.round(km))} كم • الزاوية ${ad(Math.round(QB))}° من الشمال`;
  qDraw();
  qiblaStop();window.addEventListener('deviceorientationabsolute',oriA,true);window.addEventListener('deviceorientation',oriB,true);
  if(window.DeviceOrientationEvent&&DeviceOrientationEvent.requestPermission){$('#compBtn').hidden=false;$('#compBtn').onclick=async()=>{try{await DeviceOrientationEvent.requestPermission();$('#compBtn').hidden=true}catch(e){}}}
  clearTimeout(sensT);sensT=setTimeout(()=>{if(!SENS)$('#qInfo').textContent+=' — البوصلة غير متاحة في جهازك، استخدم الزاوية مع بوصلة خارجية.'},2500);
}
function qiblaStop(){window.removeEventListener('deviceorientationabsolute',oriA,true);window.removeEventListener('deviceorientation',oriB,true)}

/* ---------- Quran ---------- */
const NORM=s=>s.replace(/[\u0610-\u061A\u064B-\u065F\u0670\u06D6-\u06ED\u0640]/g,'').replace(/[أإآٱ]/g,'ا').replace(/ى/g,'ي').replace(/ة/g,'ه');
let QM='s',IDX=null;
const typ=t=>t==='m'?'مكية':'مدنية';
function qList(){
  const bm=store.get('bm',null);
  $('#resume').innerHTML=bm?`<button class="resume" id="rs">تابع القراءة<br><b>سورة ${QURAN[bm.n-1][0]} • آية ${ad(bm.i)}</b></button>`:'';
  if(bm)$('#rs').onclick=()=>openSurah(bm.n,bm.i);
  if(QM==='s')$('#qList').innerHTML=QURAN.map((s,i)=>`<button class="it" data-n="${i+1}"><span class="num"><i>${ad(i+1)}</i></span><div><b>سورة ${s[0]}</b><small>${typ(s[1])} • ${ad(s[2].length)} آية</small></div></button>`).join('');
  else $('#qList').innerHTML=JUZ.map((j,i)=>`<button class="it" data-n="${j[0]}" data-i="${j[1]}"><span class="num"><i>${ad(i+1)}</i></span><div><b>الجزء ${ad(i+1)}</b><small>يبدأ من سورة ${QURAN[j[0]-1][0]} آية ${ad(j[1])}</small></div></button>`).join('');
}
$('#qList').onclick=e=>{const b=e.target.closest('.it,.res');if(b)openSurah(+b.dataset.n,+b.dataset.i||0)};
$('#seg').onclick=e=>{const b=e.target.closest('button');if(!b)return;QM=b.dataset.m;$$('#seg button').forEach(x=>x.classList.toggle('on',x===b));qList()};
$('#qs').oninput=e=>{
  const q=NORM(e.target.value.trim());
  if(q.length<2){$('#seg').hidden=false;return qList()}
  if(!IDX){IDX=[];QURAN.forEach((s,n)=>s[2].forEach((v,i)=>IDX.push([n+1,i+1,NORM(v)])))}
  $('#seg').hidden=true;$('#resume').innerHTML='';
  const r=[];for(const x of IDX){if(x[2].includes(q)){r.push(x);if(r.length>=50)break}}
  $('#qList').innerHTML=r.length?r.map(x=>`<button class="res" data-n="${x[0]}" data-i="${x[1]}"><small>سورة ${QURAN[x[0]-1][0]} • آية ${ad(x[1])}</small>${QURAN[x[0]-1][2][x[1]-1]}</button>`).join(''):'<p class="note">لا توجد نتائج</p>';
};
let CUR=0;
function openSurah(n,aya){
  CUR=n;const[name,t,v]=QURAN[n-1],bm=store.get('bm',null);
  $('#rTitle').textContent='سورة '+name;
  let h=`<div class="banner">سورة ${name}<small>${typ(t)} • ${ad(v.length)} آية</small></div>`;
  if(n!==1&&n!==9)h+='<p class="bsm">بِسۡمِ ٱللَّهِ ٱلرَّحۡمَٰنِ ٱلرَّحِيمِ</p>';
  h+='<div class="mus">'+v.map((x,i)=>`<span class="a${bm&&bm.n===n&&bm.i===i+1?' bm':''}" data-i="${i+1}">${x} <em>\u06DD${ad(i+1)}</em></span>`).join(' ')+'</div>';
  if(n<114)h+=`<p style="text-align:center;margin-top:24px"><button class="btn g" id="nextS">السورة التالية</button></p>`;
  $('#rBody').innerHTML=h;$('#reader').hidden=false;$('#reader').scrollTop=0;
  if(aya){const el=$(`.a[data-i="${aya}"]`);el&&setTimeout(()=>el.scrollIntoView({block:'center'}),50)}
  const nb=$('#nextS');if(nb)nb.onclick=()=>openSurah(n+1);
}
$('#rBody').onclick=e=>{const a=e.target.closest('.a');if(!a)return;store.set('bm',{n:CUR,i:+a.dataset.i});$$('.a.bm').forEach(x=>x.classList.remove('bm'));a.classList.add('bm');toast('تم حفظ علامة القراءة')};
$('#rBack').onclick=()=>{$('#reader').hidden=true;qList()};
let FS=store.get('fs',28);const setFS=()=>document.documentElement.style.setProperty('--fs',FS+'px');setFS();
$('#fPlus').onclick=()=>{FS=Math.min(46,FS+2);store.set('fs',FS);setFS()};
$('#fMinus').onclick=()=>{FS=Math.max(20,FS-2);store.set('fs',FS);setFS()};

/* ---------- Sunnah ---------- */
const RAW=[['ركعتان قبل الفجر','خير من الدنيا وما فيها'],['أربع ركعات قبل الظهر','بتسليمتين'],['ركعتان بعد الظهر',''],['ركعتان بعد المغرب',''],['ركعتان بعد العشاء','']];
const DAY=[['صلاة الضحى','ركعتان أو أكثر بعد الشروق بربع ساعة'],['الوتر','ركعة أو أكثر قبل النوم أو آخر الليل'],['أذكار الصباح',''],['أذكار المساء',''],['أذكار بعد الصلاة','33 تسبيحة و33 تحميدة و34 تكبيرة'],['آية الكرسي بعد كل صلاة',''],['ركعتان بعد الوضوء',''],['سورة الملك قبل النوم','']];
function sunnah(){
  const day='sn'+new Date().toDateString(),st=store.get(day,{});
  const mk=(el,a,p)=>{$(el).innerHTML=a.map((x,i)=>`<label class="sn"><input type="checkbox" data-k="${p+i}" ${st[p+i]?'checked':''}><div><b>${x[0]}</b><small>${x[1]}</small></div></label>`).join('')};
  mk('#sRaw',RAW,'r');mk('#sDay',DAY,'d');prog();
  $$('.sn input').forEach(c=>c.onchange=()=>{const s=store.get(day,{});s[c.dataset.k]=c.checked;store.set(day,s);st[c.dataset.k]=c.checked;prog()});
  function prog(){const t=RAW.length+DAY.length,d=Object.values(st).filter(Boolean).length;$('#pg').style.width=d/t*100+'%';$('#pgT').textContent=`${ad(d)} من ${ad(t)}`}
}

/* ---------- start ---------- */
async function start(force){
  await locate();
  try{TM=await getTimes(new Date())}catch(e){$('#status').textContent='تعذر تحميل المواقيت. تأكد من الإنترنت.';return}
  render();tick();
  if(NATIVE)nativeSchedule();else webSchedule();
}
qList();sunnah();start();
if(!NATIVE&&'serviceWorker' in navigator)navigator.serviceWorker.register('sw.js').catch(()=>{});
